package com.chenyiming.upload.controller;

import com.chenyiming.upload.entity.Algorithm;
import com.chenyiming.upload.service.AlgorithmService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/algorithm")
public class MultiRemoteController {
    @Autowired
    private AlgorithmService algorithmService;

    @PostMapping("/{name}")
    @ResponseBody
    public String addAlgorithm(@RequestParam(value = "algorithm file") MultipartFile file, Algorithm algorithm) {
        algorithmService.addAlgorithm(file, algorithm);
        return "Success";
    }
}
