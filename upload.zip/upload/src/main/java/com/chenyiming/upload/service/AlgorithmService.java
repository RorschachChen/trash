package com.chenyiming.upload.service;

import com.chenyiming.upload.entity.Algorithm;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

//@Service
public interface AlgorithmService {

    String addAlgorithm(MultipartFile file, Algorithm algorithm);

}
