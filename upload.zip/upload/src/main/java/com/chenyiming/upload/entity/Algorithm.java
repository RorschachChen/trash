package com.chenyiming.upload.entity;

import lombok.Data;

@Data
public class Algorithm {

    public int Id;
    public String name;

}
