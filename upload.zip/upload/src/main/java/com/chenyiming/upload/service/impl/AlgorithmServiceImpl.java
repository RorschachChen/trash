package com.chenyiming.upload.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.chenyiming.upload.entity.Algorithm;
import com.chenyiming.upload.mapper.AlgorithmMapper;
import com.chenyiming.upload.service.AlgorithmService;
import com.chenyiming.upload.util.UploadUtil;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

@Service
public class AlgorithmServiceImpl extends ServiceImpl<AlgorithmMapper, Algorithm> implements AlgorithmService  {

    @Override
    public String addAlgorithm(MultipartFile file, Algorithm algorithm) {
        baseMapper.insert(algorithm);

        // 存放上传图片的文件夹
        File fileDir = UploadUtil.getImgDirFile();
        // 拿到文件名
        String extName = file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf("."));
        String uuidName = UUID.randomUUID().toString();
        try {
            // 构建真实的文件路径
            File newFile = new File(fileDir.getAbsolutePath() + File.separator +uuidName+ extName);

            // 上传图片到 -> “绝对路径”
            file.transferTo(newFile);

        } catch (IOException e) {
            e.printStackTrace();
        }
        return "success";
    }

}
