package com.chenyiming.upload.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.chenyiming.upload.entity.Algorithm;

public interface AlgorithmMapper extends BaseMapper<Algorithm> {
}
