package com.chenyiming.upload.controller;

import org.springframework.core.io.FileSystemResource;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.ResourceUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.File;

public class UploadRemoteController {
    /**
     * 处理文件上传
     */
    @RequestMapping("/remoteupload")
    @ResponseBody
    public String douploadRemote(HttpServletRequest request, @RequestParam("file") MultipartFile multipartFile) {

        if (multipartFile.isEmpty()) {
            return "file is empty.";
        }

        String originalFilename = multipartFile.getOriginalFilename();
        String newFileName = UUIDHelper.uuid().replace("-", "") + originalFilename.substring(originalFilename.lastIndexOf(".") - 1);
        File file = null;
        try {
            File path = new File(ResourceUtils.getURL("classpath:").getPath());
            File upload = new File(path.getAbsolutePath(), "static/tmpupload/");
            if (!upload.exists()) upload.mkdirs();
            String uploadPath = upload + "\\";
            file = new File(uploadPath + newFileName);
            multipartFile.transferTo(file);

            // 提交到另一个服务
            FileSystemResource remoteFile = new FileSystemResource(file);
            // package parameter.
            MultiValueMap<String, Object> multiValueMap = new LinkedMultiValueMap<>();
            multiValueMap.add("file", remoteFile);

            String remoteaddr = "http://localhost:12345/test/doupload";
            String res = restTemplate.postForObject(remoteaddr, multiValueMap, String.class);

            return res;
        } catch (Exception e) {
            return "file upload error.";
        } finally {
            try{
                file.delete();
            } catch (Exception e) {
                // nothing.
            }
            return "ok";
        }
    }
}

