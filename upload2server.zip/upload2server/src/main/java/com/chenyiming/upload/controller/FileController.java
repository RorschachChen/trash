package com.chenyiming.upload.controller;

import com.chenyiming.upload.util.FileHandleUtil;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@RequestMapping(path = "/files")
@RestController
public class FileController {


    @Value("${smas.captrue.image.path}")
    private String captureImagePath;

    @Value("${file.uploadFolder}")
    private String uploadFolder;

    @Value("${file.uri}")
    private String uri;

    @RequestMapping(value = "/upload")
    public FileVo emailUpload(HttpServletRequest request) {
        MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
        Map<String, MultipartFile> files = multipartRequest.getFileMap();
        String path_deposit = uploadFolder + captureImagePath;

        List<String> urls = new ArrayList<>();
        for (Map.Entry<String, MultipartFile> entry : files.entrySet()) {
            try {
                String fileName = entry.getValue().getOriginalFilename();
                FileHandleUtil.upload(entry.getValue().getInputStream(), path_deposit, fileName);
                urls.add(FileHandleUtil.getServerIPPort(request) + File.separator + uri + fileName);
            } catch (IOException e) {
                throw new SmasException("文件读取异常");
            }
        }

        FileVo fileVo = new FileVo();
        fileVo.setErrno("0");
        fileVo.setData(urls);

        return fileVo;
    }
}