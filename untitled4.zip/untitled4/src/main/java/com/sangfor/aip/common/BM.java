package com.sangfor.aip.common;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import lombok.Data;

import java.util.Date;

@Data
public class BM {
    @TableId
    private Long id;

    @TableField
    private Date createTime;

    @TableField
    private Date updateTime;
}
