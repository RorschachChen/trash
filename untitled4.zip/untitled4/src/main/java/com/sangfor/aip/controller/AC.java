package com.sangfor.aip.controller;

import com.baomidou.mybatisplus.plugins.pagination.PageHelper;
import com.github.pagehelper.PageInfo;
import com.sangfor.aip.entity.A;
import com.sangfor.aip.service.AS;
import com.sangfor.aip.util.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/a")
public class AC {

    @Autowired
    AS as;

    @GetMapping("/{atId}")
    public PageInfo getAList(
            @RequestParam(value = "page number", defaultValue = "1") Integer pageNum,
            @RequestParam(value = "page size", defaultValue = "50") Integer pageSize,
            @PathVariable Integer atId) {
        PageHelper.startPage(pageNum, pageSize);
        List<A> list = as.getAList(atId);
        PageInfo pageInfo = new PageInfo<>(list);
        return pageInfo;
    }

    @GetMapping("/{keyword}")
    public PageInfo query(
            @RequestParam(value = "page number", defaultValue = "1") Integer pageNum,
            @RequestParam(value = "page size", defaultValue = "50") Integer pageSize,
            @PathVariable String keyword) {
        PageHelper.startPage(pageNum, pageSize);
        List<A> list = as.query(keyword);
        PageInfo pageInfo = new PageInfo<>(list);
        return pageInfo;
    }


}
