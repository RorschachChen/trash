package com.sangfor.aip.mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.sangfor.aip.entity.AT;

public interface ATM extends BaseMapper<AT> {
}
