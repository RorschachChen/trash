package com.sangfor.aip.entity;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;
import com.sangfor.aip.common.BM;
import lombok.Data;

@TableName("A")
@Data
public class A extends BM {

    @TableField(value = "name")
    private String name;

    @TableField(value = "description")
    private String Descripiton;

    private Integer atId;

    public A(String name, String descripiton, Integer atid) {
        super();
        this.name = name;
        Descripiton = descripiton;
        this.atId = atId;
    }

    public A() {
    }
}
