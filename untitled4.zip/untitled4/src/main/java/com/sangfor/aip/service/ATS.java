package com.sangfor.aip.service;

import com.sangfor.aip.entity.A;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

@Service
public interface ATS {


}
