package com.sangfor.aip.controller;

import com.sangfor.aip.entity.A;
import com.sangfor.aip.service.ATS;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/at")
public class ATC {

//    @Autowired
//    ATS ats;

    // t_post -> A,  t_user -> AT
//    @GetMapping("/{atId}")
//    public List<A> getAList(@PathVariable Integer atId) {
//        return ats.getAList(atId);
//    }

}
