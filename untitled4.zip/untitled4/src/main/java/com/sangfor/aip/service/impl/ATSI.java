//package com.sangfor.aip.service.impl;
//
//import com.baomidou.mybatisplus.service.impl.ServiceImpl;
//import com.sangfor.aip.entity.A;
//import com.sangfor.aip.entity.AT;
//import com.sangfor.aip.mapper.ATM;
//import com.sangfor.aip.service.ATS;
//import org.springframework.stereotype.Service;
//import org.springframework.web.bind.annotation.PathVariable;
//
//import java.util.List;
//
//@Service
//public class ATSI extends ServiceImpl<ATM, AT> implements ATS {
//
//    @Override
//    public List<A> getAList(@PathVariable Integer atId) {
//
//    }
//}
