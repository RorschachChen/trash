package com.sangfor.aip.mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.sangfor.aip.entity.A;

public interface AM extends BaseMapper<A> {

//    IPage<A> selectPageVo(Page<?> page, Integer state);
}
