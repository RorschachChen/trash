package com.sangfor.aip.entity;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;
import com.sangfor.aip.common.BM;

@TableName("AT")
public class AT extends BM {

    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    @TableField(value = "name")
    private String name;

    @TableField(value = "description")
    private String Descripiton;


    public AT(Long id, String name, String descripiton) {
        this.id = id;
        this.name = name;
        Descripiton = descripiton;
    }

    public AT() {
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescripiton() {
        return Descripiton;
    }

    public void setDescripiton(String descripiton) {
        Descripiton = descripiton;
    }
}
